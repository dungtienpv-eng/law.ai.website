document.addEventListener('DOMContentLoaded', () => {
    console.log('Law AI website loaded');
});
